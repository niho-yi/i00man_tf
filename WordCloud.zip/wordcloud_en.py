import nltk
nltk.download('book', quiet=True)
from nltk.book import *

nltk.corpus.gutenberg.fileids()
emma_raw = nltk.corpus.gutenberg.raw("austen-emma.txt")
print(emma_raw[:1302])

from nltk.tokenize import sent_tokenize
print(sent_tokenize(emma_raw[:1000])[3])

from nltk.tokenize import word_tokenize
word_tokenize(emma_raw[50:100])

from nltk.tokenize import RegexpTokenizer
retokenize = RegexpTokenizer("[\w]+")
retokenize.tokenize(emma_raw[50:100])

words = ['lives', 'crying', 'flies', 'dying']

from nltk.stem import PorterStemmer
st = PorterStemmer()
[st.stem(w) for w in words]

from nltk.stem import LancasterStemmer
st = LancasterStemmer()
[st.stem(w) for w in words]


from nltk.stem import WordNetLemmatizer
lm = WordNetLemmatizer()
[lm.lemmatize(w) for w in words]

lm.lemmatize("dying", pos="v")

nltk.help.upenn_tagset('VB')

from nltk.tag import pos_tag
sentence = "Emma refused to permit us to obtain the refuse permit"
tagged_list = pos_tag(word_tokenize(sentence))
tagged_list



